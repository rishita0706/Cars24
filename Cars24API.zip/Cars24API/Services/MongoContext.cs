using Cars24API.Models;
using MongoDB.Driver;

namespace Cars24API.Services
{
    public class MongoContext
    {
        public IMongoCollection<Car> Cars { get; }

        public MongoContext(IConfiguration configuration)
        {
            var client = new MongoClient(
                configuration.GetConnectionString("Cars24DB"));

            var database = client.GetDatabase(
                configuration["MongoDB:DatabaseName"]);

            Cars = database.GetCollection<Car>("Cars");
        }
    }
}