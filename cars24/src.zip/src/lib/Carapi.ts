// src/lib/Carapi.ts
// const BASE_URL = "https://cars24-74k0.onrender.com/api/Car";
const BASE_URL = "https://http://localhost:3000/api/Car";

type CarDetails = {
  title: string;
  images: string[];
  price: string;
  emi: string;
  location: string;
  specs: {
    year: number;
    km: string;
    fuel: string;
    transmission: string;
    owner: string;
    insurance: string;
  };
  features: string[];
  highlights: string[];
};
export const createCar = async (carDetails: CarDetails) => {
  const response = await fetch(`${BASE_URL}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(carDetails),
  });
  return response.json();
};
export const getcarByid = async (id: string) => {
  const response = await fetch(`${BASE_URL}/${id}`);
  return response.json();
};
export const getcarSummaries = async () => {
  const response = await fetch(`${BASE_URL}/summaries`);
  return response.json();
};

// ---------------------------------------------------------------------------
// Search / Suggestions
// Backed by GET /api/Car/search and GET /api/Car/suggestions (CarSearchService).
//
// NOTE: this assumes GET /api/Car/search returns the paginated wrapper shape
// { totalResults, page, pageSize, totalPages, results: [{ car, score }] }.
// Make sure CarSearchService.SearchAsync on the backend returns that shape
// (SearchResponse), not a bare array - otherwise the pagination/sorting UI
// below will have nothing to read.
// ---------------------------------------------------------------------------

// Mirrors the full Car document shape returned inside search results
// (as opposed to the trimmed-down summary shape from getcarSummaries).
export type CarFull = {
  id: string;
  images: string[];
  title: string;
  price: string;
  emi: string;
  location: string;
  specs: {
    year: number;
    km: string;
    fuel: string;
    transmission: string;
    owner: string;
    insurance: string;
  };
  features: string[];
  highlights: string[];
};

export type SearchResultItem = {
  car: CarFull;
  score: number;
};

export type SearchResponse = {
  totalResults: number;
  page: number;
  pageSize: number;
  totalPages: number;
  results: SearchResultItem[];
};

export type CarSuggestion = {
  text: string;
  type: string; // "Title" | "Feature" | "Highlight" | "Fuel" | "Transmission" | "Location"
};

export type CarSearchParams = {
  query?: string;
  fuel?: string;
  transmission?: string;
  location?: string;
  owner?: string;
  year?: number;
  minYear?: number;
  maxYear?: number;
  minMileage?: number;
  maxMileage?: number;
  minPrice?: number;
  maxPrice?: number;
  features?: string[];
  highlights?: string[];
  page?: number;
  pageSize?: number;
  sortBy?: string;
};

export const searchCars = async (
  params: CarSearchParams
): Promise<SearchResponse> => {
  const query = new URLSearchParams();

  if (params.query) query.append("query", params.query);
  if (params.fuel) query.append("fuel", params.fuel);
  if (params.transmission) query.append("transmission", params.transmission);
  if (params.location) query.append("location", params.location);
  if (params.owner) query.append("owner", params.owner);
  if (params.year !== undefined) query.append("year", String(params.year));
  if (params.minYear !== undefined) query.append("minYear", String(params.minYear));
  if (params.maxYear !== undefined) query.append("maxYear", String(params.maxYear));
  if (params.minMileage !== undefined)
    query.append("minMileage", String(params.minMileage));
  if (params.maxMileage !== undefined)
    query.append("maxMileage", String(params.maxMileage));
  if (params.minPrice !== undefined) query.append("minPrice", String(params.minPrice));
  if (params.maxPrice !== undefined) query.append("maxPrice", String(params.maxPrice));
  if (params.page !== undefined) query.append("page", String(params.page));
  if (params.pageSize !== undefined) query.append("pageSize", String(params.pageSize));
  if (params.sortBy) query.append("sortBy", params.sortBy);
  // ASP.NET Core binds repeated query keys into a List<string>, so each item
  // needs its own "features=" / "highlights=" entry rather than a single
  // comma-joined value.
  params.features?.forEach((f) => query.append("features", f));
  params.highlights?.forEach((h) => query.append("highlights", h));

  const response = await fetch(`${BASE_URL}/search?${query.toString()}`);
  return response.json();
};

export const getCarSuggestions = async (
  q: string
): Promise<CarSuggestion[]> => {
  const trimmed = q.trim();
  if (!trimmed) return [];
  const response = await fetch(
    `${BASE_URL}/suggestions?q=${encodeURIComponent(trimmed)}`
  );
  return response.json();
};